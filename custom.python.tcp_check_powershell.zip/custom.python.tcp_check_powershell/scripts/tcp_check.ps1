param(
    [Parameter(Mandatory = $True)]
    [string]
    $IP,

    [Parameter(Mandatory = $True)]
    [string]
    $Port
)

$tcp = New-Object System.Net.Sockets.TcpClient
Try
{
    $tcp.connect($IP, $Port)
    Write-Host "State:OK"
    Write-Host "Description:TCP Example Description"
}
Catch
{
    Write-Host "State:ERROR"
    Write-Host "Description:TCP Example Description"
}
